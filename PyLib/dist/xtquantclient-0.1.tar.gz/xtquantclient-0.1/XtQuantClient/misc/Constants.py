
from decimal import Decimal

decXtQuantAssetPrecision = Decimal('0.01')
decXtQuantPricePrecision = Decimal('0.001')
